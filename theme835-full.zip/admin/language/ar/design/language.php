<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'محرر اللغات';

// Text
$_['text_success']     = 'تم التعديل !';
$_['text_edit']        = 'تحرير';
$_['text_default']     = 'الافتراضي';
$_['text_store']       = 'المتجر';
$_['text_language']    = 'اللغة';
$_['text_translation'] = 'اختيار الترجمة';
$_['text_translation'] = 'الترجمة';

// Entry
$_['entry_key']        = 'المفتاح';
$_['entry_value']      = 'القيمة';
$_['entry_default']    = 'الافتراضي';

// Error
$_['error_permission'] = 'تحذير: انت لا تمتلك صلاحيات التعديل !';
