<?php
// Heading
$_['heading_title']    = 'Flat Rate';

// Text
$_['text_shipping']    = 'Shipping';
$_['text_success']     = 'Success: You have modified flat rate shipping!';
$_['text_edit']        = 'تحرير';

// Entry
$_['entry_cost']       = 'سعر الشحن:';
$_['entry_tax_class']  = 'نوع الضريبة';
$_['entry_geo_zone']   = 'المنطقة الجغرافية :';
$_['entry_status']     = 'الحالة :';
$_['entry_sort_order'] = 'ترتيب الفرز :';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';